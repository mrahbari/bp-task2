-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Feb 06, 2022 at 11:21 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.12

SET FOREIGN_KEY_CHECKS=0;
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bp_task2_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_migrations`
--

DROP TABLE IF EXISTS `tbl_migrations`;
CREATE TABLE `tbl_migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_migrations`
--

REPLACE INTO `tbl_migrations` (`id`, `migration`, `batch`) VALUES
(1, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(2, '2022_02_06_175741_create_transactions_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_personal_access_tokens`
--

DROP TABLE IF EXISTS `tbl_personal_access_tokens`;
CREATE TABLE `tbl_personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_transactions`
--

DROP TABLE IF EXISTS `tbl_transactions`;
CREATE TABLE `tbl_transactions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_transactions`
--

REPLACE INTO `tbl_transactions` (`id`, `code`, `amount`, `user_id`, `created_at`, `updated_at`) VALUES
(1, 'T_218_ljydmgebx', '8617.19', 375, '2020-01-19 12:38:59', '2020-01-19 12:38:59'),
(2, 'T_335_wmhrbjxld', '6502.72', 1847, '2020-01-19 12:38:59', '2020-01-19 12:38:59'),
(3, 'T_327_shqnyrctz', '101.26', 3031, '2020-01-19 12:38:59', '2020-01-19 12:38:59'),
(4, 'T_570_qtbdktdxn', '5032.74', 5441, '2020-01-19 12:38:59', '2020-01-19 12:38:59'),
(5, 'T_696_yruawfpis', '2710.4', 6019, '2020-01-19 12:38:59', '2020-01-19 12:38:59'),
(6, 'T_445_qxlmjdoas', '9062.91', 948, '2020-01-19 12:38:59', '2020-01-19 12:38:59'),
(7, 'T_836_ajvlpejea', '3112.48', 4369, '2020-01-19 12:38:59', '2020-01-19 12:38:59'),
(8, 'T_681_mefjlmzuz', '6282.17', 3814, '2020-01-19 12:38:59', '2020-01-19 12:38:59'),
(9, 'T_351_tfdmvutme', '8380.54', 1262, '2020-01-19 12:38:59', '2020-01-19 12:38:59'),
(10, 'T_271_hlixsoqta', '8353.47', 5395, '2020-01-19 12:38:59', '2020-01-19 12:38:59'),
(11, 'T_624_vmochibpg', '6026.96', 2632, '2020-01-19 12:38:59', '2020-01-19 12:38:59'),
(12, 'T_395_hguojrgdl', '175.35', 6968, '2020-01-19 12:38:59', '2020-01-19 12:38:59'),
(13, 'T_224_himeftdia', '4889.66', 3674, '2020-01-19 12:38:59', '2020-01-19 12:38:59'),
(14, 'T_894_ykmqjgdwo', '4556.98', 8540, '2020-01-19 12:38:59', '2020-01-19 12:38:59'),
(15, 'T_771_crijwmlhi', '7464.33', 7988, '2020-01-19 12:38:59', '2020-01-19 12:38:59'),
(16, 'T_141_dlkkwcvqi', '4353.48', 6776, '2020-01-19 12:38:59', '2020-01-19 12:38:59'),
(17, 'T_924_jporprlnq', '1583.18', 8976, '2020-01-19 12:38:59', '2020-01-19 12:38:59'),
(18, 'T_743_anyfqbtai', '5752.01', 6887, '2020-01-19 12:38:59', '2020-01-19 12:38:59'),
(19, 'T_922_aicbljcdw', '1231.31', 1916, '2020-01-19 12:38:59', '2020-01-19 12:38:59'),
(20, 'T_246_lvqdeoypx', '8851.42', 950, '2020-01-19 12:38:59', '2020-01-19 12:38:59'),
(21, 'T_096_hcsqzzvho', '742.51', 3412, '2020-01-19 12:38:59', '2020-01-19 12:38:59'),
(22, 'T_989_iarrgdtcq', '119.97', 9491, '2020-01-19 12:38:59', '2020-01-19 12:38:59'),
(23, 'T_763_htmagmnre', '7976.47', 6016, '2020-01-19 12:38:59', '2020-01-19 12:38:59'),
(24, 'T_752_mjbwdpcge', '5976.13', 449, '2020-01-19 12:38:59', '2020-01-19 12:38:59'),
(25, 'T_576_bylwniwho', '8035.72', 2515, '2020-01-19 12:38:59', '2020-01-19 12:38:59'),
(26, 'T_838_lenphejbj', '5507.09', 867, '2020-01-19 12:38:59', '2020-01-19 12:38:59'),
(27, 'T_126_jpffzmrnj', '7510.11', 6472, '2020-01-19 12:38:59', '2020-01-19 12:38:59'),
(28, 'T_654_fgrfdhrvt', '6160', 5167, '2020-01-19 12:38:59', '2020-01-19 12:38:59'),
(29, 'T_931_tvsksgtcs', '8925.06', 7766, '2020-01-19 12:38:59', '2020-01-19 12:38:59'),
(30, 'T_128_oopsjulgg', '2465.76', 6598, '2020-01-19 12:38:59', '2020-01-19 12:38:59'),
(31, 'T_716_elwcpchjp', '1658.38', 6149, '2020-01-19 12:38:59', '2020-01-19 12:38:59'),
(32, 'T_035_dihnlsrbi', '5677.89', 4457, '2020-01-19 12:38:59', '2020-01-19 12:38:59'),
(33, 'T_943_mlvxcuspl', '2621.56', 4934, '2020-01-19 12:38:59', '2020-01-19 12:38:59'),
(34, 'T_988_jjyaacsxc', '7645.41', 7121, '2020-01-19 12:38:59', '2020-01-19 12:38:59'),
(35, 'T_524_egtxfmlbc', '4006.38', 1420, '2020-01-19 12:38:59', '2020-01-19 12:38:59'),
(36, 'T_022_hsrqfsmja', '3492.29', 7091, '2020-01-19 12:38:59', '2020-01-19 12:38:59'),
(37, 'T_618_vouqdxemh', '148.75', 1838, '2020-01-19 12:38:59', '2020-01-19 12:38:59'),
(38, 'T_243_dhuskwtoh', '2614.35', 2974, '2020-01-19 12:38:59', '2020-01-19 12:38:59'),
(39, 'T_216_qorynonhk', '3759.76', 3534, '2020-01-19 12:38:59', '2020-01-19 12:38:59'),
(40, 'T_509_jpqmoqiaf', '2297.97', 5933, '2020-01-19 12:38:59', '2020-01-19 12:38:59'),
(41, 'T_516_wfxfzmvpp', '3488.63', 2467, '2020-01-19 12:38:59', '2020-01-19 12:38:59'),
(42, 'T_011_phzomfguw', '9844.47', 2485, '2020-01-19 12:38:59', '2020-01-19 12:38:59'),
(43, 'T_057_tpxymzluv', '460.92', 8538, '2020-01-19 12:38:59', '2020-01-19 12:38:59'),
(44, 'T_069_tmrvtochy', '123.21', 7966, '2020-01-19 12:38:59', '2020-01-19 12:38:59'),
(45, 'T_996_gmgduxuvt', '5818.87', 5412, '2020-01-19 12:38:59', '2020-01-19 12:38:59'),
(46, 'T_816_prvlpksih', '2830.62', 263, '2020-01-19 12:38:59', '2020-01-19 12:38:59'),
(47, 'T_875_pyuxmkgfk', '3065.04', 8113, '2020-01-19 12:38:59', '2020-01-19 12:38:59'),
(48, 'T_101_fjuxdjumr', '2468.51', 1756, '2020-01-19 12:38:59', '2020-01-19 12:38:59'),
(49, 'T_818_qnhiwtyyv', '1077.57', 9678, '2020-01-19 12:38:59', '2020-01-19 12:38:59'),
(50, 'T_631_deojxgntm', '15.47', 4032, '2020-01-19 12:38:59', '2020-01-19 12:38:59'),
(51, 'T_232_mavowvrci', '2390.77', 8511, '2020-01-19 12:38:59', '2020-01-19 12:38:59'),
(52, 'T_284_dxbashvbd', '1265.71', 8397, '2020-01-19 12:38:59', '2020-01-19 12:38:59'),
(53, 'T_817_ewniforqr', '5159.5', 2410, '2020-01-19 12:38:59', '2020-01-19 12:38:59'),
(54, 'T_132_uulxwnfvc', '3398.81', 1360, '2020-01-19 12:38:59', '2020-01-19 12:38:59'),
(55, 'T_819_enkzzkimt', '2555.39', 1984, '2020-01-19 12:38:59', '2020-01-19 12:38:59'),
(56, 'T_905_lejtvumsz', '6903.98', 942, '2020-01-19 12:38:59', '2020-01-19 12:38:59'),
(57, 'T_679_fedvlpgta', '6064.82', 8560, '2020-01-19 12:38:59', '2020-01-19 12:38:59'),
(58, 'T_184_fbteapfyy', '9343.52', 2025, '2020-01-19 12:38:59', '2020-01-19 12:38:59'),
(59, 'T_494_arbpsymku', '6462.11', 6095, '2020-01-19 12:38:59', '2020-01-19 12:38:59'),
(60, 'T_803_wyosijzjf', '1676.39', 6440, '2020-01-19 12:38:59', '2020-01-19 12:38:59'),
(61, 'T_300_ttqhpimht', '5572.24', 4134, '2020-01-19 12:38:59', '2020-01-19 12:38:59'),
(62, 'T_263_iobpsxzxa', '2844.58', 5729, '2020-01-19 12:38:59', '2020-01-19 12:38:59'),
(63, 'T_154_jdetfixgq', '3885.1', 3317, '2020-01-19 12:38:59', '2020-01-19 12:38:59'),
(64, 'T_666_qggzhlheg', '5708.91', 5211, '2020-01-19 12:38:59', '2020-01-19 12:38:59'),
(65, 'T_486_exsahbagp', '342.5', 824, '2020-01-19 12:38:59', '2020-01-19 12:38:59'),
(66, 'T_453_sekdfamvg', '6874.26', 5937, '2020-01-19 12:38:59', '2020-01-19 12:38:59'),
(67, 'T_373_ybyfrsiqz', '2138.27', 4604, '2020-01-19 12:38:59', '2020-01-19 12:38:59'),
(68, 'T_389_qmclahzhw', '446.38', 8619, '2020-01-19 12:38:59', '2020-01-19 12:38:59'),
(69, 'T_811_bdlggytjn', '3366.74', 9324, '2020-01-19 12:38:59', '2020-01-19 12:38:59'),
(70, 'T_700_niljtmoaa', '9811.38', 8654, '2020-01-19 12:38:59', '2020-01-19 12:38:59'),
(71, 'T_483_ajasuxzcr', '8163.74', 3801, '2020-01-19 12:38:59', '2020-01-19 12:38:59'),
(72, 'T_050_agtrqgynk', '5132.55', 5666, '2020-01-19 12:38:59', '2020-01-19 12:38:59'),
(73, 'T_630_ocmulkkjx', '7838.68', 8288, '2020-01-19 12:38:59', '2020-01-19 12:38:59'),
(74, 'T_907_zcceufqyj', '5006.9', 3369, '2020-01-19 12:38:59', '2020-01-19 12:38:59'),
(75, 'T_486_ogsgahzjw', '4156.66', 7076, '2020-01-19 12:38:59', '2020-01-19 12:38:59'),
(76, 'T_227_pkcwunxtr', '8479.72', 1764, '2020-01-19 12:38:59', '2020-01-19 12:38:59'),
(77, 'T_845_wzijrfdfx', '6666.69', 648, '2020-01-19 12:38:59', '2020-01-19 12:38:59'),
(78, 'T_557_zwguofjny', '2513.49', 1724, '2020-01-19 12:38:59', '2020-01-19 12:38:59'),
(79, 'T_509_qrzpxfnbk', '3357.22', 8574, '2020-01-19 12:38:59', '2020-01-19 12:38:59'),
(80, 'T_242_tyglkcjxo', '240.18', 4005, '2020-01-19 12:38:59', '2020-01-19 12:38:59'),
(81, 'T_514_jicraifpj', '9252.21', 541, '2020-01-19 12:38:59', '2020-01-19 12:38:59'),
(82, 'T_714_ofpomwdfw', '7475.07', 9655, '2020-01-19 12:38:59', '2020-01-19 12:38:59'),
(83, 'T_550_jvltclqwp', '4910.63', 1619, '2020-01-19 12:38:59', '2020-01-19 12:38:59'),
(84, 'T_148_wdcznkgic', '4571.82', 8642, '2020-01-19 12:38:59', '2020-01-19 12:38:59'),
(85, 'T_705_galluaqty', '8504.33', 5727, '2020-01-19 12:38:59', '2020-01-19 12:38:59'),
(86, 'T_899_vlpnztojx', '7566.62', 1936, '2020-01-19 12:38:59', '2020-01-19 12:38:59'),
(87, 'T_722_dqfnksnqo', '6881.46', 9900, '2020-01-19 12:38:59', '2020-01-19 12:38:59'),
(88, 'T_411_jptxwbety', '7166.86', 4828, '2020-01-19 12:38:59', '2020-01-19 12:38:59'),
(89, 'T_000_xmnzboeld', '9589.13', 2684, '2020-01-19 12:38:59', '2020-01-19 12:38:59'),
(90, 'T_678_hcxdmmcde', '5286.49', 1338, '2020-01-19 12:38:59', '2020-01-19 12:38:59'),
(91, 'T_613_pnyymkeho', '9400.34', 4653, '2020-01-19 12:38:59', '2020-01-19 12:38:59'),
(92, 'T_489_omimaakqo', '2058.72', 8807, '2020-01-19 12:38:59', '2020-01-19 12:38:59'),
(93, 'T_748_vephvwnjn', '4831.98', 420, '2020-01-19 12:38:59', '2020-01-19 12:38:59'),
(94, 'T_911_dloibftfj', '1804.67', 514, '2020-01-19 12:38:59', '2020-01-19 12:38:59'),
(95, 'T_677_tpxmkdabf', '4800.64', 2289, '2020-01-19 12:38:59', '2020-01-19 12:38:59'),
(96, 'T_011_qwhmkrhql', '5164.78', 9116, '2020-01-19 12:38:59', '2020-01-19 12:38:59'),
(97, 'T_346_ivqjhurnv', '6423.57', 2214, '2020-01-19 12:38:59', '2020-01-19 12:38:59'),
(98, 'T_463_jqixkploc', '2547.1', 485, '2020-01-19 12:38:59', '2020-01-19 12:38:59'),
(99, 'T_217_orikmnjie', '2977.93', 1399, '2020-01-19 12:38:59', '2020-01-19 12:38:59'),
(100, 'T_924_zduerrqxw', '3491.17', 7253, '2020-01-19 12:38:59', '2020-01-19 12:38:59');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_migrations`
--
ALTER TABLE `tbl_migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_personal_access_tokens`
--
ALTER TABLE `tbl_personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `tbl_personal_access_tokens_token_unique` (`token`),
  ADD KEY `tbl_personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `tbl_transactions`
--
ALTER TABLE `tbl_transactions`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_migrations`
--
ALTER TABLE `tbl_migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_personal_access_tokens`
--
ALTER TABLE `tbl_personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_transactions`
--
ALTER TABLE `tbl_transactions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=101;
SET FOREIGN_KEY_CHECKS=1;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
